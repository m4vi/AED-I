#include <stdio.h>
float ConvFahren(float celsius)
{
    return (celsius*9/5)+32;
}