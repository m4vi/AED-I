#include <stdio.h>

int main()
{
    int anos;
    float s;

    printf("Digite o tempo de servico: ");
    scanf("%d", &anos);

    printf("Digite o salario: ");
    scanf("%f", &s);

    if (anos >= 5)
    {
        s= s*0.25;
    }
    else 
    {
        s=s*0.1;
    }
    printf("O bonus eh: %2.f", s);
    return 0;
}
