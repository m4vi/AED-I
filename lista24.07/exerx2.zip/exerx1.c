#include <stdio.h>

int main()
{
    char ps;
    int exame;
    float valor;

    printf("Voce tem plano de saude?: S para Sim e N para nao ");
    scanf("%c", &ps);

    printf("Digite o exame escolhido: ");
    scanf("%d", &exame);

    if (exame == 501)
    {
        valor = 28.97;
        if (ps == 'S')
        {
            valor = valor * 0.85;
            printf("Hemograma completo com desconto eh %f:", valor);
        }
        else
            printf("Hemograma completo eh %f:", valor);
    }
    else if (exame == 502)
    {
        valor = 22.87;
        if (ps == 'S')
        {
            valor = valor * 0.85;
            printf("Colesterol com desconto eh %f:", valor);
        }
        else
            printf("Colesterol eh %f:", valor);
    }
    else if (exame == 503)
    {
        valor = 23.74;
        if (ps == 'S')
        {
            valor = valor * 0.85;
            printf("Creatinina e ureia com desconto eh %f:", valor);
        }
        else
            printf("Creatinina e ureia eh %f:", valor);
    }
    else if (exame == 504)
    {
        valor = 19.74;
        if (ps == 'S')
        {
            valor = valor * 0.85;
            printf("Glicemia com desconto eh %f:", valor);
        }
        else
            printf("Glicemia eh %f:", valor);
    }
    else if (exame == 505)
    {
        valor = 26.22;
        if (ps == 'S')
        {
            valor = valor * 0.85;
            printf("Triglicerídeos com desconto eh %f:", valor);
        }
        else
            printf("Triglicerídeos eh %f:", valor);
    }
    else if (exame == 506)
    {
        valor = 33.47;
        if (ps == 'S')
        {
            valor = valor * 0.85;
            printf("Transaminases com desconto eh %f:", valor);
        }
        else
            printf("Creatinina e ureia eh %f:", valor);
    }
    else if (exame == 507)
    {
        valor = 29.99;
        if (ps == 'S')
        {
            valor = valor * 0.85;
            printf("Ácido úrico com desconto eh %f:", valor);
        }
        else
            printf("Ácido úrico eh %f:", valor);
    }
    else
    {
        printf("Opcao invalida");
    }
    return 0;
}
