#include <stdio.h>

int main() {
    int n1, n2, n3;
    float m1, m2, m3, m;

    printf("Digite o n1:");
    scanf("%d", &n1);

    printf("Digite o n2:");
    scanf("%d", &n2);

    printf("Digite o n3:");
    scanf("%d", &n3);

        if (n1%2 == 0) {
            m1 = 5.5;
        }
        else {
            m1=4.50;
        }
        if (n2%2 == 0) {
            m2 = 5.5;
        }
        else {
            m2=4.50;
        }
        if (n3%2 == 0) {
            m3 = 5.5;
        }
        else {
            m3=4.50;
        }

    m = ((n1*m1)+(n2*m2)+(n3*m3))/(m1+m2+m3);
    printf("Media ponderada: %f", m);
    
    return 0;
}