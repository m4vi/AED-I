#include <stdio.h>

int main()
{
    int i = 450;

    while (i < 680)
    {
        if (i % 2 != 0)
        {
            printf(" %d ", i);
        }
        i++;
    }
    return 0;
}