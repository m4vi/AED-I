#include <stdio.h>

int main()
{
    float maior_media = 0, menor_media = 10, media, numerador = 0, denominador = 0;

    printf("Digite a media, ou -m se quer sair: ");
    scanf("%f", &media);

    while (media >= 0)
    {
        if (media > maior_media)
        {
            maior_media = media;
        }
        if (media < menor_media)
        {
            menor_media = media;
        }
        numerador = numerador + media;
        denominador = denominador + 1;

        printf("Digite a media, ou -m se quer sair: ");
        scanf("%f", &media);
    }
    if (denominador != 0)
    {
        printf("Media aritmetica: %.2f e a menor media: %.2f e a maior media: %.2f ", numerador / denominador, menor_media, maior_media);
    }
    return 0;
}