#include <stdio.h>

int main()
{
    int i = 0, s = 0, n;

    while (i < 10)
    {
        printf("Digite um num: ");
        scanf("%d", &n);

        if (n % 2 != 0)
        {
            s++;
        }
        i++;
    }
    printf("Impares: %d", s);
    return 0;
}