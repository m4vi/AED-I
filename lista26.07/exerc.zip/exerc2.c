#include <stdio.h>
int main()
{
    int i = 0, s = 0, n;

    while (i < 8)
    {
        printf("Digite um num: ");
        scanf("%d", &n);

        if (n % 2 == 0)
        {
            s = s + n;
        }
        i++;
    }
    printf("Soma dos pares: %d", s);
    return 0;
}