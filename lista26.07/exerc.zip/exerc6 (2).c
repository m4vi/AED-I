#include <stdio.h>

int main()
{
    int s = 0, n = 0, d = 0, m = 0;
    printf("Digite o salario, ou -1 se quer sair: ");
    scanf("%d", &s);
    while (s != -1)
    {
        n = n + s;
        d = d + 1;
        printf("Digite o salario, ou -1 se quer sair: ");
        scanf("%d", &s);
    }
    if (d!=0) {
        m = n / d;
    printf("Media dos salarios: %d e soma dos salarios: %d ", m, n);
    }
    return 0;
}
// eu tive um bug com o denominador da media por isso eu tive q iniciar ele com -1