#include <stdio.h>

int main()
{
    int i = 0, d = 0, nu = 0, m, n;

    while (i < 5)
    {
        printf("Digite um num: ");
        scanf("%d", &n);

        if (n % 2 != 0)
        {
            d++;
            nu = nu + n;
        }
        i++;
    }
    m = nu / d;
    printf("Media dos impares: %d", m);
    return 0;
}