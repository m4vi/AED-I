#include <stdio.h>

int main(){

float litros_vendidos, v;
int tipo;

printf("Para o tipo de combustivel digite: 1 para alcool, 2 para gasolina, 3 para diesel:\n");
scanf("%d", &tipo);

if ((tipo ==1) || (tipo == 2) || (tipo == 3)) {
       printf("Escreva o numero de litros vendidos:\n");
scanf("%f", &litros_vendidos);
}

    if ((tipo == 1)){
        if (litros_vendidos<10) {
            v = (4.5*litros_vendidos)*0.97;
        }
        else {
         v = (4.5*litros_vendidos)*0.95;
        }
    }
        else if (tipo == 2) {
            if (litros_vendidos<15) {
                v = (5.1*litros_vendidos)*0.99;
            } 
            else {
            v = (5.1*litros_vendidos)*0.96;
            }
        }
        else if (tipo == 3) {
            if (litros_vendidos<20) {
                v = (5.25*litros_vendidos)*0.97;
            } 
            else {
            v = (5.25*litros_vendidos)*0.94;
            
            }
        }
    else {
        printf("Opcao invalida");
    }
    if ((tipo ==1) || (tipo == 2) || (tipo == 3)) {
        printf("Valor a ser pago: %f", v);
    }
return 0;
}