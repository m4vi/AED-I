#include <stdio.h>

int main(){

int num1, num2, quociente, resto;

printf("Escreva o valor do primeiro numero:\n");
scanf("%d", &num1);

printf("Escreva o valor do segundo numero:\n");
scanf("%d", &num2);

quociente = num1/num2;
resto = num1 % num2;

printf("O resto da divisao eh : %d e o quociente eh : %d \n", resto, quociente);


return 0;
}