#include <stdio.h>

int main(){

float preco, v;
int tipo;

printf("Para o tipo de pagamento digite: 1 para pix, 2 para cartao de debito, 3 para a vista no cartao de credito e 4 para parcelado no cartao de credito:\n");
scanf("%d", &tipo);

printf("Digite o preco original:\n");
scanf("%f", &preco);


    if ((tipo == 1)){
        v = preco*0.9;
    }
        else if (tipo == 2) {
           v = preco * 0.95;
           printf("Valor a ser pago: %.2f", v);
        }
        else if (tipo == 3) {
            v = preco * 0.98;
            printf("Valor a ser pago: %.2f", v);
        }
        else if (tipo == 4) {
            v = preco;
            printf("Valor a ser pago: %.2f", v);
        }
    else {
        printf("Opacao invalida");
        }

return 0;
}