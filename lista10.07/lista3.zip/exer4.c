#include <stdio.h>

int main(){

int A, B, C;

printf("Escreva o valor do primeiro numero:\n");
scanf("%d", &A);

printf("Escreva o valor do segundo numero:\n");
scanf("%d", &B);

printf("Escreva o valor do terceiro numero:\n");
scanf("%d", &C);

    if ((B + C) == A){
        printf("A soma de %d e %d é igual a %d.\n", B, C, A);
    }
        else if ((B + C) < A) {
        printf("A soma de %d e %d é menor que %d.\n", B, C, A);
        }
        else {
        printf("A soma de %d e %d é maior que %d.\n", B, C, A);
         }


return 0;
}