#include <stdio.h>

int main(){

int num, sucessor, antecessor;

printf("Escreva um numero:\n");
scanf("%d", &num);

 sucessor =  num + 1;
 antecessor = num - 1;


  printf("O valor inicial eh:%d\n", num);
  printf("O sucessor eh:%d\n", sucessor);
  printf("O antecessor eh:%d\n", antecessor);



 return 0;



}