# include <stdio.h>

int main()
{
char letra;

printf("Digite uma letra Maiuscula: ");
scanf("%c", &letra);

switch (letra)
{
    case 'A':
        printf ("Vogal A");
        break;
    case 'E':
        printf ("Vogal B");
        break;
    case 'I':
        printf ("Vogal I");
        break;
    case 'O':
        printf ("Vogal O");
        break;
    case 'U':
        printf ("Vogal U");
        break;
    default:
    printf("Consoante");
}


return 0;
}