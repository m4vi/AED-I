# include <stdio.h>

int main()
{
int t, tam;
float p, valor;

printf ("Digite o tipo: Tipo 1 - lagarta, Tipo 2 - gafanhotos, Tipo 3 - ferrugem, Tipo 4 - todos acima: ");
scanf("%d", &t);

printf ("Digite o tamanho em metros quadrados: ");
scanf("%d", &tam);

switch (t)
    {
        case 1:
            valor = (tam*75);
            if (tam>500) {
                valor = valor*0.95;
            }
            if (valor>50000) {
                p= valor-50000;
                valor = valor - (p*0.15);
            }
            printf("Valor a pagar: %f", valor);
            break;
        case 2:
            valor = (tam*98);
            if (tam>500) {
                valor = valor*0.95;
            }
            if (valor>50000) {
                p= valor-50000;
                valor = valor - (p*0.15);
            }
            printf("Valor a pagar: %f", valor);
            break;
        case 3:
            valor = (tam*108);
            if (tam>500) {
                valor = valor*0.95;
            }
            if (valor>50000) {
                p= valor-50000;
                valor = valor - (p*0.15);
            }
            printf("Valor a pagar: %f", valor);
            break;
        case 4:
            valor = (tam*202);
            if (tam>500) {
                valor = valor*0.95;
            }
            if (valor>50000) {
                p= valor-50000;
                valor = valor - (p*0.15);
            }
            printf("Valor a pagar: %f", valor);
            break;
        default:
        printf("Opcao invalida");

    }
    return 0;
}

