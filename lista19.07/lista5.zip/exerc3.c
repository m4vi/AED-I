# include <stdio.h>

int main()
{
int codigo, quantidade;

printf("Digite o codigo do produto: ");
scanf("%i", &codigo);
printf("Digite a quantidade de produto: ");
scanf("%i", &quantidade);

switch (codigo)
{
    case 200:
        printf("Baguncinha, quantidade: %i, valor total a pagar: %f", quantidade, quantidade*21.7);
        break;
    case 201:
        printf("Bagunca caseiro, quantidade: %i, valor total a pagar: %f", quantidade, quantidade*28.9);
        break;
    case 202:
        printf("X salada, quantidade: %i, valor total a pagar: %f", quantidade, quantidade*18.2);
        break;
    case 203:
        printf("Bauru simples, quantidade: %i, valor total a pagar: %f", quantidade, quantidade*15.99);
        break;
    case 204:
        printf("Refrigerante, quantidade: %i, valor total a pagar: %i", quantidade, quantidade*6);
        break;
    case 205:
        printf("Agua mineral, quantidade: %i, valor total a pagar: %i", quantidade, quantidade*4);
        break;
    default:
    printf("código invalido");
}

return 0;
}