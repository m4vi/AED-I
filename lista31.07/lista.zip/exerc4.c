#include <stdio.h>
#define masculino 1
#define feminino 2
#define azuis 3
#define verdes 4
#define castanhos 5
#define louro 6
#define castanho 7
#define ruivo 8
#define preto 9
int main()
{
    float media;
    int sexo, cont1 = 0, cont2=0, numerador_idade=0, demominador_idade=0, maior_idade=0, cor_olhos, cor_cabelo, idade;
    do
    {
        printf("Digite seu sexo 1 Masculino 2 feminino -1 para parar: ");
        scanf("%d", &sexo);
        if (sexo == -1)
        {
            break;
        }
        printf("Digite a cor dos olhos 3 azuis 4 verdes 5 castanhos: ");
        scanf("%d", &cor_olhos);
        printf("Digite a cor do cabelo 6 louro 7 castanhos 8 ruivos 9 pretos: ");
        scanf("%d", &cor_cabelo);
        printf("Digite sua idade: ");
        scanf("%d", &idade);

        numerador_idade = numerador_idade + idade;
        demominador_idade++;

        if ((sexo == masculino) && (idade >= 20) && (idade <= 25) && (cor_olhos == castanhos) && (cor_cabelo == louro))
        {
            cont1++;
        }
        if (idade > maior_idade)
        {
            maior_idade = idade;
        }
        if ((sexo==feminino) && (idade>=34) && (idade<=41) && (cor_olhos==azuis) && (cor_cabelo==preto))
        {
            cont2++;
        }
        
    } while (sexo != -1);
    if (demominador_idade != 0)
    {
       media = numerador_idade/demominador_idade; 
        printf("Média idade: %2.f \n maior idade %d \n", media, maior_idade);
        printf("Quantidade de individuos do sexo masculino cuja idade está entre 20 e 25 anos e que tenham olhos castanhos e cabelos louros: %d \t \n", cont1);
        printf("Quantidade de individuos do sexo feminino cuja idade está entre 34 e 41 anos e que tenham olhos azul e cabelos pretos: %d", cont2);
    }
    return 0;
}