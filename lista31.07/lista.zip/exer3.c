#include <stdio.h>

int main()
{
    int i = 0;
    float r=150, l=120;
    do
    {
        r=r+2.5;
        l = l + 4;
        i++;
    } while (l<r);
    printf("Serão necessarios %d anos para que Lucas seja maior que Rafael", i);
    return 0;
}