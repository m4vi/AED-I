#include <stdio.h>

int main()
{
    int num, quan, c;
    float valor = 0;
    printf("Voce possui o cartao da loja? Digite 1 para Sim e 2 para nao: ");
    scanf("%d", &c);
    do
    { // inicio do
        printf("Digite o codigo do produto: ");
        scanf("%d", &num);
        if (num == -1)
        {
            break;
        } // para de executar tudo
        printf("Digite a quantidade: ");
        scanf("%d", &quan);
        switch (num)
        { // inicio switch case
        case 79001:
            if (c == 1 || quan >= 3) 
            {
                valor = valor + (1.95 * quan);
            }
            else
            {
                valor = valor + (2.10 * quan);
            }
            break;
        case 79002:
            if (c == 1 || quan >= 2)
            {
                valor = valor + (8.2 * quan);
            }
            else
            {
                valor = valor + (8.39 * quan);
            }
            break;
        case 79003:
            if (c == 1 || quan >= 4)
            {
                valor = valor + (3.99 * quan);
            }
            else
            {
                valor = valor + (4.21 * quan);
            }
            break;
        case 79004:
            if (c == 1 || quan >= 3)
            {
                valor = valor + (4.8 * quan);
            }
            else
            {
                valor = valor + (4.99 * quan);
            }
            break;
        case 79005:
            if (c == 1 || quan >= 2)
            {
                valor = valor + (19.85 * quan);
            }
            else
            {
                valor = valor + (21 * quan);
            }
            break;
        case 79006:
            if (c == 1 || quan >= 5)
            {
                valor = valor + (5.55 * quan);
            }
            else
            {
                valor = valor + (5.99 * quan);
            }
            break;
        case 79007:
            if (c == 1 || quan >= 7)
            {
                valor = valor + (1.99 * quan);
            }
            else
            {
                valor = valor + (2.15 * quan);
            }
        default:
            printf("Codigo invalido");
            break;
        }
    } while (num != -1);
    printf("Valor total da compra: %2.f \n", valor);
    return 0;
}
