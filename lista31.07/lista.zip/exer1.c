#include <stdio.h>

int main()
{
    int n, num, i = 0;
    printf("Digite um numero: ");
    scanf("%d", &num);
    do
    {
        n = num * i;
        printf("%d * %d = %d \n", num, i, n);
        i++;
    } while (i <= 10);

    return 0;
}