#include <stdio.h>

int main()
{
    int num;
    printf("Digite um numero: ");
    scanf("%d", &num);
   
    for ( int i=num; i>=num-20; i--)
    {
        printf("%d ", i);    
    }

    return 0;
}