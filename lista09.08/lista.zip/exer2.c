#include <stdio.h>

int main()
{
    int soma = 0, i;
    for (i = 2; i <= 42; i++)
    {
        if (i % 3 == 0)
        {
            soma = soma + i;
            printf("%d\n", i);
        }
    }
    printf("soma: %d ", soma);
    return 0;
}