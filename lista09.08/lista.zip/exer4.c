#include <stdio.h>

int main()
{
    int idade, i, cont;
    for (i = 0; i < 15; i++)
    {
        printf("Digite idade: ");
        scanf("%i", &idade);
        if (idade > 25)
        {
            cont++;
        }
    }
    printf("Cont idades: %d ", cont);
    return 0;
}