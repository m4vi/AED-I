#include <stdio.h>
int main()
{
    float todas_as_compras = 0, contcartao = 0, contdinheiro = 0, contpix = 0, valor;
    char codigo;
    for (int i = 0; i < 3; i++)
    {
        printf("C para compras no cartão (não importa se é débito ou crédito ");
        printf("\nP para compras no pix e D para compras usando dinheiro.");
        fflush(stdin);
        printf("Digite o código: ");
        scanf("%c", &codigo);

        printf("Digite o valor: ");
        scanf("%f", &valor);

        switch (codigo)
        {
        case 'C':
            contcartao=contcartao+valor;
            break;
        case 'D':
            contdinheiro=contdinheiro+valor;
            break;
        case 'P':
            contpix=contpix+valor;
            break;
        default:
            printf("Opcão invalida");
            break;
        }
    }
    todas_as_compras = contcartao+contdinheiro+contpix;

    printf("soma total: %.2f \n", todas_as_compras);
    printf("Soma cartão: %.2f \n", contcartao);
    printf("Soma Pix: %.2f \n", contpix);
    printf("Soma dinheiro: %.2f", contdinheiro);

    return 0;
}